import { useState, useEffect } from 'react';

const colors = ['Red', 'Blue', 'Green', 'Yellow', 'Purple', 'Orange', 'Pink', 'Cyan'];

export default function Home() {
  const [selectedColor, setSelectedColor] = useState(null);
  const [timeLeft, setTimeLeft] = useState(80);
  const [raceInProgress, setRaceInProgress] = useState(false);
  const [message, setMessage] = useState('');
  const [farcasterId, setFarcasterId] = useState('demo_user'); // Replace with actual Farcaster auth

  useEffect(() => {
    const interval = setInterval(() => {
      setTimeLeft((prev) => (prev <= 1 ? 80 : prev - 1));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const handlePlay = async () => {
    if (!selectedColor) return;
    setRaceInProgress(true);
    setMessage('Racing...');

    setTimeout(async () => {
      const res = await fetch('/api/play', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ farcaster_id: farcasterId, selected_color: selectedColor })
      });

      const data = await res.json();
      if (data.error) {
        setMessage(data.error);
      } else {
        setMessage(data.won ? `You won ${data.reward} $ZED!` : 'Sorry, not this time.');
      }
      setRaceInProgress(false);
    }, 4000);
  };

  return (
    <div className="min-h-screen bg-black text-white p-4 flex flex-col items-center">
      <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-zedGradientStart to-zedGradientEnd">
        ZED Champs Lite
      </h1>
      <p className="text-sm mb-4">Next race in: {timeLeft}s</p>

      <div className="grid grid-cols-4 gap-2 mb-4">
        {colors.map((color) => (
          <button
            key={color}
            className={\`px-3 py-2 rounded-full text-sm font-semibold \${selectedColor === color ? 'bg-gradient-to-r from-zedGradientStart to-zedGradientEnd text-black' : 'bg-gray-800 hover:bg-gray-700'}\`}
            onClick={() => setSelectedColor(color)}
            disabled={raceInProgress}
          >
            {color}
          </button>
        ))}
      </div>

      <button
        onClick={handlePlay}
        disabled={raceInProgress}
        className="bg-gradient-to-r from-zedGradientStart to-zedGradientEnd text-black px-6 py-2 rounded font-bold"
      >
        Start Race
      </button>

      <div className="mt-6 text-lg">{message}</div>
    </div>
  );
}
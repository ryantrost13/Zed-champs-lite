import { createClient } from '@supabase/supabase-js';

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

export default async function handler(req, res) {
  const { farcaster_id, selected_color } = req.body;

  const { data: user } = await supabase.from('users').select('*').eq('farcaster_id', farcaster_id).single();
  const today = new Date().toISOString().split('T')[0];

  if (!user) {
    await supabase.from('users').insert({ farcaster_id, plays_today: 1, last_played: today });
  } else if (user.last_played === today && user.plays_today >= 25) {
    return res.status(403).json({ error: 'Daily play limit reached' });
  } else {
    await supabase.from('users').update({
      plays_today: user.last_played === today ? user.plays_today + 1 : 1,
      last_played: today
    }).eq('farcaster_id', farcaster_id);
  }

  const { data: race } = await supabase
    .from('races')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(1)
    .single();

  const won = selected_color === race.winner;
  const reward = won ? Math.floor(Math.random() * 91) + 10 : 0;

  await supabase.from('picks').insert({
    user_id: user?.id,
    race_id: race.id,
    selected: selected_color,
    won,
    reward
  });

  if (won) {
    await fetch(process.env.PAYOUT_WEBHOOK, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        farcaster_id,
        amount: reward
      })
    });
  }

  res.status(200).json({ won, reward });
}
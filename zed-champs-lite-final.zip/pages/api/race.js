import { createClient } from '@supabase/supabase-js';

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

export default async function handler(req, res) {
  const colors = ['Red', 'Blue', 'Green', 'Yellow', 'Purple', 'Orange', 'Pink', 'Cyan'];
  const winner = colors[Math.floor(Math.random() * colors.length)];

  const { error } = await supabase.from('races').insert([{ winner }]);
  if (error) return res.status(500).json({ error });

  return res.status(200).json({ winner });
}
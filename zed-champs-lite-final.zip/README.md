# ZED Champs Lite

Farcaster mini-app for dot racing prediction. Players pick a colored dot they think will win the race. Every 80 seconds a new race begins. Winners earn $ZED rewards.

## Features

- Farcaster Sign In (SIWF)
- 8 Dot Color Picker (Red, Blue, Green, etc.)
- Vertical race every 80 seconds
- 25 free plays per user per day
- Win screen on correct guess
- Backend stores race + pick history
- Webhook triggers for payout
- Styled using ZED Champions branding

## Setup

1. Install deps
```bash
npm install
```

2. Create a `.env.local`:
```env
SUPABASE_URL=...
SUPABASE_KEY=...
PAYOUT_WEBHOOK=https://...
```

3. Start dev server
```bash
npm run dev
```

4. Schedule `/api/race` to run every 80 seconds (via cron or external)

## Auth & Identity

Farcaster Sign In is used to authenticate players via FID, which is stored in Supabase and used to enforce 25 plays/day.

## Tech Stack

- Next.js (Pages Router)
- Supabase (DB)
- TailwindCSS (UI)
- Farcaster Auth Kit
- Vercel Cron or Upstash for race scheduler